import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import {
  obtenerProducto,
  modificarProducto,
  reactivarProducto,
  asignarMaterialAProducto,
  modificarCantidadDeMaterial,
  quitarMaterialDeProducto,
  asignarCategoriaAProducto,
  quitarCategoriaDeProducto,
  subirImagenDeProducto,
  modificarImagenDeProducto,
  borrarImagenDeProducto,
} from './api'

// Tercer import que cruza de funcionalidad, con el mismo criterio de
// siempre: el endpoint pertenece a esa app y ahí se queda. Acá hacen falta
// las listas completas para elegir qué agregarle al producto.
import { listarCategorias } from '../categorias/api'
import { listarMateriales } from '../materiales/api'
import { ANCHO_MAXIMO, BASE_GESTION } from '../../constantes'

import Toast from '../../componentes/Toast'
import ChipCambiosSinGuardar from '../../componentes/ChipCambiosSinGuardar'

import PestanaDatos from './PestanaDatos'
import PestanaMateriales from './PestanaMateriales'
import PestanaCategorias from './PestanaCategorias'
import PestanaImagenes from './PestanaImagenes'
import ModalAgregarMaterial from './ModalAgregarMaterial'
import ModalBajaProducto from './ModalBajaProducto'
import {
  COLOR_DIFICULTAD,
  ICONO_IMAGEN,
  estadoCatalogoFicha,
  formatearPrecio,
  motivoFuera,
  textoDificultad,
} from './presentacion'


const ICONO_FLECHA = 'M9 5l7 7-7 7'
const ICONO_ALERTA = 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z'

const PESTANAS = [
  { id: 'datos', label: 'Datos' },
  { id: 'materiales', label: 'Materiales' },
  { id: 'imagenes', label: 'Imágenes' },
  { id: 'categorias', label: 'Categorías' },
]


// Los campos que edita el formulario de Datos. El precio va como texto
// porque el input es de texto; se convierte al guardar.
function borradorDe(producto) {
  return {
    nombre: producto.nombre,
    descripcion: producto.descripcion,
    precio: String(Math.round(Number(producto.precio_actual))),
    dificultad: producto.dificultad,
    paso_a_paso: producto.paso_a_paso,
    es_personalizado: producto.es_personalizado,
  }
}


// El backend contesta de dos formas según qué falló: las reglas de negocio
// mandan {'detail': '...'} y los errores de campo mandan
// {'imagen': ['La imagen pesa 20.0 MB...']}. La subida de fotos usa la
// segunda, así que hay que mirar las dos para no tragarse el mensaje.
// El orden de una foto nueva: uno más que el mayor de su grupo, o 0 si el
// grupo está vacío. No se usa la cantidad de fotos: después de borrar una
// del medio, la cantidad repite un orden que ya existe, y dos fotos con el
// mismo orden no se pueden intercambiar.
function siguienteOrden(imagenes, tipo) {
  const delGrupo = imagenes.filter((i) => i.tipo === tipo)
  if (delGrupo.length === 0) return 0
  return Math.max(...delGrupo.map((i) => i.orden)) + 1
}

function mensajeDeError(err) {
  const datos = err.response?.data
  if (!datos) return 'No se pudo completar la acción.'
  if (datos.detail) return datos.detail

  const primerCampo = Object.values(datos)[0]
  if (Array.isArray(primerCampo) && primerCampo.length > 0) return primerCampo[0]

  return 'No se pudo completar la acción.'
}


// Tiene que ser el mismo 1440 que la media query grande de index.css, por
// lo mismo que PANTALLA_CHICA en Layout.jsx: React decide si el panel del
// resumen existe y CSS reparte las dos columnas, y los dos tienen que
// cambiar en el mismo ancho.
const PANTALLA_GRANDE = '(min-width: 1440px)'

// Dice si la pantalla es grande (1440px o más) y se actualiza sola cuando
// la ventana cruza ese ancho. Es usePantallaChica de Layout.jsx con la otra
// consulta; queda acá porque este es su único consumidor.
function usePantallaGrande() {
  const [grande, setGrande] = useState(() => window.matchMedia(PANTALLA_GRANDE).matches)

  useEffect(() => {
    const consulta = window.matchMedia(PANTALLA_GRANDE)
    const actualizar = (evento) => setGrande(evento.matches)
    consulta.addEventListener('change', actualizar)
    return () => consulta.removeEventListener('change', actualizar)
  }, [])

  return grande
}


function Chip({ texto, color, fondo }) {
  return (
    <span
      style={{
        fontFamily: "'Quicksand', sans-serif",
        fontWeight: 600,
        fontSize: 14,
        borderRadius: 20,
        padding: '5px 14px',
        border: `1px solid ${color}`,
        background: fondo,
        color,
      }}
    >
      {texto}
    </span>
  )
}


// El panel de la derecha en pantalla grande: la imagen principal y, debajo,
// el mismo resumen de la cabecera más las categorías. Solo se dibuja en la
// pestaña Datos, y solo de 1440px para arriba: en
// los otros anchos la cabecera ya dice lo mismo, y un panel escondido con
// CSS igual descargaría la imagen en el celular.
function ResumenDelProducto({ producto, activo, dificultad, catalogo }) {
  // La principal es la primera de tipo RESULTADO, como en PestanaImagenes.
  const principal = producto.imagenes.find((i) => i.tipo === 'RESULTADO')

  // contain: 'size' hace que el panel no cuente para el alto de la fila: lo
  // pone el formulario, y el panel se estira hasta ahí. La foto ocupa todo el
  // ancho y el alto que deja el resumen de abajo; objectFit: 'cover' la
  // recorta sin deformarla.
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        contain: 'size',
        background: 'white',
        border: '1px solid #EBE0E2',
        borderRadius: 8,
        overflow: 'hidden',
      }}
    >
      {principal ? (
        <img
          src={principal.imagen}
          alt={producto.nombre}
          style={{
            display: 'block',
            flex: '1 1 0',
            minHeight: 0,
            width: '100%',
            objectFit: 'cover',
          }}
        />
      ) : (
        <div
          style={{
            flex: '1 1 0',
            minHeight: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 10,
            background: '#FAF7F7',
            borderBottom: '1px solid #EBE0E2',
            fontSize: 14,
            color: '#B08791',
          }}
        >
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#B08791" strokeWidth="1.5">
            <path strokeLinecap="round" strokeLinejoin="round" d={ICONO_IMAGEN} />
          </svg>
          Sin imagen
        </div>
      )}

      <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <span style={{ fontFamily: "'Quicksand', sans-serif", fontWeight: 700, fontSize: 22, color: '#8C5A66' }}>
          {formatearPrecio(producto.precio_actual)}
        </span>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <Chip texto={textoDificultad(producto)} color={dificultad.color} fondo={dificultad.fondo} />
          <Chip
            texto={producto.estado_display}
            color={activo ? '#4E8C6A' : '#C0442F'}
            fondo={activo ? '#E8F5EF' : '#FAEAE8'}
          />
          <Chip texto={catalogo.texto} color={catalogo.color} fondo={catalogo.fondo} />
        </div>

        <div>
          <p
            style={{
              margin: '0 0 8px',
              fontFamily: "'Quicksand', sans-serif",
              fontWeight: 600,
              fontSize: 13,
              color: '#857078',
              letterSpacing: '.06em',
            }}
          >
            CATEGORÍAS
          </p>

          {producto.categorias.length === 0 ? (
            <span style={{ fontSize: 14, color: '#857078' }}>Sin categorías</span>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              {/* Rosa las de tipo y amarillo las temáticas: los mismos colores
                  que usa PestanaCategorias. */}
              {producto.categorias.map((c) => (
                <Chip
                  key={c.id}
                  texto={c.nombre}
                  color={c.tipo === 'TEMATICA' ? '#D9A441' : '#8C5A66'}
                  fondo={c.tipo === 'TEMATICA' ? '#FDF3E0' : '#F0E2E4'}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}


// La ficha de un producto que ya existe (/productos/:id). El alta vive
// aparte, en AltaProducto: junta todo en memoria y lo crea al final.
export default function DetalleProducto() {
  const { id } = useParams()
  const navegar = useNavigate()

  const [producto, setProducto] = useState(null)
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')
  const [tab, setTab] = useState('datos')

  // El borrador de Datos vive ACÁ y no en PestanaDatos, al revés que el
  // borrador del modal de filtros. El motivo es que tiene que sobrevivir al
  // cambio de pestaña: si viviera en la pestaña, pasar a Materiales la
  // desmontaría y se perdería lo escrito.
  const [borrador, setBorrador] = useState(null)
  const [guardando, setGuardando] = useState(false)

  const [categorias, setCategorias] = useState([])
  const [materiales, setMateriales] = useState([])

  const [modalMaterial, setModalMaterial] = useState(false)
  const [modalBaja, setModalBaja] = useState(false)

  // El error de las imágenes va aparte del general, y guarda EN QUÉ GRUPO
  // falló: { tipo, mensaje }. Se muestra arriba de la grilla de ese grupo,
  // al lado del botón que lo provocó, y no al final de la pestaña, donde
  // quedaba tan lejos que no se veía.
  const [errorImagen, setErrorImagen] = useState(null)
  const [toast, setToast] = useState('')
  const temporizador = useRef(null)
  const pantallaGrande = usePantallaGrande()

  useEffect(() => {
    obtenerProducto(id)
      .then((res) => {
        setProducto(res.data)
        setBorrador(borradorDe(res.data))
      })
      .catch(() => setError('No se pudo cargar el producto.'))
      .finally(() => setCargando(false))

    listarCategorias().then((res) => setCategorias(res.data)).catch(() => {})
    listarMateriales().then((res) => setMateriales(res.data)).catch(() => {})
  }, [id])




  function mostrarToast(texto) {
    setToast(texto)
    // Se cancela el anterior: si no, al hacer dos acciones seguidas el
    // temporizador de la primera apaga el cartel de la segunda antes de
    // tiempo.
    clearTimeout(temporizador.current)
    temporizador.current = setTimeout(() => setToast(''), 2600)
  }


  // Las acciones sobre materiales y categorías se aplican EN EL MOMENTO,
  // a diferencia de la pestaña Datos, que junta los cambios y espera al
  // botón de GUARDAR. La razón es que son hechos consumados: agregarle una categoría
  // a un producto es un caso de uso que ya pasó (CU25), no un campo que se
  // está editando. Por eso no hay botón de guardar en esas pestañas, y por
  // eso confirman con un toast.
  //
  // Todos estos endpoints devuelven la ficha completa, ya recalculada por
  // el backend, así que se usa esa respuesta en vez de volver a pedir el
  // producto: es un viaje menos y no hay un momento con datos viejos.
  async function accionInmediata(llamada, textoToast) {
    setError('')
    try {
      const res = await llamada()
      setProducto(res.data)
      // El texto es opcional: si la acción ya se ve en pantalla, no se
      // llama con ninguno y no sale ningún cartel.
      if (textoToast) mostrarToast(textoToast)
    } catch (err) {
      setError(mensajeDeError(err))
    }
  }


  // Como accionInmediata, pero para las imágenes: el error se recuerda
  // junto con el grupo donde ocurrió. Empezar cualquier acción nueva borra
  // el error anterior, así que se limpia solo al reintentar.
  async function accionDeImagen(tipo, llamada, textoToast) {
    setErrorImagen(null)
    try {
      const res = await llamada()
      setProducto(res.data)
      mostrarToast(textoToast)
    } catch (err) {
      setErrorImagen({ tipo, mensaje: mensajeDeError(err) })
    }
  }


  // Mover una imagen es intercambiar el campo 'orden' de dos: dos PATCH que
  // se mandan juntos, y recién después se refresca con la última respuesta.
  async function intercambiarOrden(a, b) {
    setErrorImagen(null)
    try {
      await modificarImagenDeProducto(id, a.id, { orden: b.orden })
      const res = await modificarImagenDeProducto(id, b.id, { orden: a.orden })
      setProducto(res.data)
      mostrarToast('Orden actualizado')
    } catch (err) {
      // Las dos son del mismo grupo, así que alcanza con el tipo de una.
      setErrorImagen({ tipo: a.tipo, mensaje: mensajeDeError(err) })
      // Si el segundo PATCH falló, el primero ya se aplicó: se vuelve a
      // pedir la ficha para mostrar cómo quedó de verdad.
      obtenerProducto(id).then((res) => setProducto(res.data)).catch(() => {})
    }
  }


  // Devuelve el id del producto si salió bien, o null si no.
  async function guardarDatos() {
    setError('')

    // Los tres que el backend exige y no tienen valor por defecto. Se
    // muestra el primero que falte: es un formulario corto y una lista de
    // errores sería más ruido que ayuda.
    if (!borrador.nombre.trim()) {
      setError('Ponele un nombre al producto.')
      return null
    }
    if (!borrador.precio) {
      setError('Ponele un precio al producto.')
      return null
    }
    if (!borrador.dificultad) {
      setError('Elegí la dificultad.')
      return null
    }

    setGuardando(true)

    const datos = {
      nombre: borrador.nombre.trim(),
      descripcion: borrador.descripcion.trim(),
      precio_actual: borrador.precio,
      dificultad: borrador.dificultad,
      paso_a_paso: borrador.paso_a_paso,
      es_personalizado: borrador.es_personalizado,
    }

    try {
      const res = await modificarProducto(id, datos)
      setProducto(res.data)
      setBorrador(borradorDe(res.data))
      mostrarToast('Cambios guardados')
      return res.data.id
    } catch (err) {
      setError(mensajeDeError(err))
      return null
    } finally {
      setGuardando(false)
    }
  }


  if (cargando) {
    return <p style={{ color: '#857078' }}>Cargando…</p>
  }

  if (!producto) {
    return <p style={{ color: '#C0442F' }}>{error || 'No se encontró el producto.'}</p>
  }


  // Derivados, calculados en cada render.
  //
  // Hay cambios si algún campo del borrador difiere del producto cargado.
  const original = borradorDe(producto)

  const hayCambios =
    borrador.nombre !== original.nombre ||
    borrador.descripcion !== original.descripcion ||
    borrador.precio !== original.precio ||
    borrador.dificultad !== original.dificultad ||
    borrador.paso_a_paso !== original.paso_a_paso ||
    borrador.es_personalizado !== original.es_personalizado


  // Salir descarta lo escrito sin preguntar. El aviso mientras se está en la
  // ficha es el chip del breadcrumb.
  function volver() {
    navegar(`${BASE_GESTION}/productos`)
  }

  // Descartar repone el formulario desde el producto guardado.
  function descartar() {
    setError('')
    setBorrador(borradorDe(producto))
  }

  // Todo lo que sigue describe el producto cargado.
  const activo = producto.estado === 'ACTIVO'
  const deBaja = producto.estado === 'BAJA'
  const dificultad = COLOR_DIFICULTAD[producto.dificultad]
  const catalogo = estadoCatalogoFicha(producto)
  const avisoOculto = activo && !producto.visible_en_catalogo && motivoFuera(producto)

  const idsAsignados = producto.categorias.map((c) => c.id)
  const categoriasDisponibles = categorias.filter(
    (c) => c.estado === 'ACTIVO' && !idsAsignados.includes(c.id)
  )

  const idsMateriales = producto.materiales_usados.map((l) => l.material)
  const materialesDisponibles = materiales.filter(
    (m) => m.estado === 'ACTIVO' && !idsMateriales.includes(m.id)
  )

  // Las cuentas de los globitos de las pestañas.
  const CUENTAS = {
    materiales: producto.cantidad_materiales,
    imagenes: producto.cantidad_imagenes,
    categorias: producto.categorias.length,
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 14 }}>
        <button
          onClick={volver}
          className="btn-ver-productos"
          style={{
            padding: 0,
            border: 0,
            background: 'transparent',
            cursor: 'pointer',
            fontFamily: "'Quicksand', sans-serif",
            fontWeight: 600,
            fontSize: 15,
            color: '#8C5A66',
          }}
        >
          Productos
        </button>

        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#B08791" strokeWidth="2.2">
          <path strokeLinecap="round" strokeLinejoin="round" d={ICONO_FLECHA} />
        </svg>

        <span style={{ fontSize: 15, color: '#857078' }}>{producto.nombre}</span>

        {hayCambios && <ChipCambiosSinGuardar />}
      </div>

      <div
        className="ancho-pantalla"
        style={{
          display: 'flex',
          alignItems: 'flex-start',
          justifyContent: 'space-between',
          gap: 20,
          marginBottom: 22,
          flexWrap: 'wrap',
          maxWidth: ANCHO_MAXIMO,
        }}
      >
        <div style={{ minWidth: 0 }}>
          <h1
            style={{
              margin: '0 0 8px',
              fontFamily: "'Quicksand', sans-serif",
              fontWeight: 600,
              fontSize: 32,
              color: '#3D3238',
              textWrap: 'pretty',
            }}
          >
            {producto.nombre}
          </h1>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <span
              style={{
                fontFamily: "'Quicksand', sans-serif",
                fontWeight: 700,
                fontSize: 22,
                color: '#8C5A66',
              }}
            >
              {formatearPrecio(producto.precio_actual)}
            </span>

            <Chip texto={textoDificultad(producto)} color={dificultad.color} fondo={dificultad.fondo} />
            <Chip
              texto={producto.estado_display}
              color={activo ? '#4E8C6A' : '#C0442F'}
              fondo={activo ? '#E8F5EF' : '#FAEAE8'}
            />
            <Chip texto={catalogo.texto} color={catalogo.color} fondo={catalogo.fondo} />
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 8 }}>
          <button
            onClick={() =>
              activo
                ? setModalBaja(true)
                : accionInmediata(() => reactivarProducto(id), 'Producto reactivado')
            }
            className="btn-reponer"
            style={{
              padding: '10px 16px',
              border: '1px solid #EBE0E2',
              background: 'white',
              color: '#8C5A66',
              borderRadius: 6,
              cursor: 'pointer',
              fontFamily: "'Quicksand', sans-serif",
              fontWeight: 600,
              fontSize: 15,
            }}
          >
            {activo ? 'Dar de baja' : 'Reactivar'}
          </button>
        </div>
      </div>

      {avisoOculto && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '12px 18px',
            marginBottom: 20,
            background: '#FAEAE8',
            border: '1px solid #f0b8b0',
            borderRadius: 6,
          }}
        >
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#C0442F"
            strokeWidth="2"
            style={{ flexShrink: 0 }}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d={ICONO_ALERTA} />
          </svg>
          <span style={{ fontSize: 15, color: '#C0442F', textWrap: 'pretty' }}>{avisoOculto}</span>
        </div>
      )}

      <div
        className="fila-pestanas"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 4,
          marginBottom: 20,
          borderBottom: '1px solid #EBE0E2',
        }}
      >
        {PESTANAS.map((p) => {
          const activa = tab === p.id
          const cuenta = CUENTAS[p.id]

          return (
            <button
              key={p.id}
              onClick={() => { setTab(p.id); setError('') }}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 7,
                padding: '11px 18px',
                border: 0,
                borderBottom: `2px solid ${activa ? '#8C5A66' : 'transparent'}`,
                background: 'transparent',
                cursor: 'pointer',
                fontFamily: "'Quicksand', sans-serif",
                fontWeight: 600,
                fontSize: 15,
                color: activa ? '#8C5A66' : '#857078',
              }}
            >
              {p.label}

              {cuenta !== undefined && (
                <span
                  style={{
                    minWidth: 20,
                    height: 20,
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '0 6px',
                    borderRadius: 10,
                    background: activa ? '#8C5A66' : '#F0E2E4',
                    color: activa ? 'white' : '#8C5A66',
                    fontSize: 12,
                    fontWeight: 700,
                  }}
                >
                  {cuenta}
                </span>
              )}
            </button>
          )
        })}
      </div>


      {/* Un producto dado de baja es de solo lectura: el fieldset
          deshabilitado apaga todos los controles de las cuatro pestañas
          (campos, botones, casillas, el selector de archivo) sin tocar cada
          uno. Reactivar queda afuera, en la cabecera, y sigue activo. */}
      <fieldset disabled={deBaja} style={{ border: 0, padding: 0, margin: 0, minWidth: 0 }}>

      {/* El contenedor es una grilla de una columna que en pantalla grande
          pasa a dos (formulario y panel del resumen) por la clase
          datos-producto. */}
      {tab === 'datos' && (
        <div
          className="ancho-pantalla datos-producto"
          // stretch: el panel se estira hasta el alto del formulario, así los
          // dos terminan alineados. Con una sola columna no cambia nada.
          style={{ display: 'grid', gap: 24, alignItems: 'stretch', maxWidth: ANCHO_MAXIMO }}
        >
          <PestanaDatos
            borrador={borrador}
            onCambiar={(cambio) => setBorrador({ ...borrador, ...cambio })}
            hayCambios={hayCambios}
            onGuardar={guardarDatos}
            onCancelar={descartar}
            guardando={guardando}
            error={error}
          />

          {pantallaGrande && (
            <ResumenDelProducto
              producto={producto}
              activo={activo}
              dificultad={dificultad}
              catalogo={catalogo}
            />
          )}
        </div>
      )}

      {tab === 'materiales' && (
        <PestanaMateriales
          lineas={producto.materiales_usados}
          onAgregar={() => setModalMaterial(true)}
          onGuardarCantidad={(linea, cantidad) =>
            accionInmediata(
              () => modificarCantidadDeMaterial(id, linea.id, cantidad),
              'Cantidad guardada'
            )
          }
          onQuitar={(linea) =>
            accionInmediata(
              () => quitarMaterialDeProducto(id, linea.id),
              `“${linea.material_nombre}” quitado`
            )
          }
        />
      )}

      {/* Diferencia deliberada con el prototipo: allá las imágenes se
          reordenan arrastrándolas, acá con dos flechitas por tarjeta.
          Arrastrar mueve un número variable de imágenes de una vez, así que
          serían N pedidos y si uno falla la galería queda a medias.
          Intercambiar de a dos es siempre la misma operación: dos PATCH que
          se cruzan el campo 'orden'. */}
      {tab === 'imagenes' && (
        <PestanaImagenes
          imagenes={producto.imagenes}
          error={errorImagen}
          onError={(tipo, mensaje) => setErrorImagen({ tipo, mensaje })}
          onSubirArchivo={(tipo, archivo) =>
            accionDeImagen(
              tipo,
              () =>
                subirImagenDeProducto(id, {
                  imagen: archivo,
                  tipo,
                  // El orden se numera por separado dentro de cada tipo,
                  // así que la nueva va al final de SU grupo. Además le da
                  // un valor distinto al de sus compañeras, que si no
                  // quedarían todas empatadas en el 0 que trae el modelo
                  // por defecto: entre dos con el mismo orden,
                  // intercambiarlo no cambiaría nada.
                  orden: siguienteOrden(producto.imagenes, tipo),
                }),
              'Imagen subida'
            )
          }
          onIntercambiar={intercambiarOrden}
          onGuardarTitulo={(imagen, titulo) =>
            accionDeImagen(
              imagen.tipo,
              () => modificarImagenDeProducto(id, imagen.id, { titulo }),
              'Título guardado'
            )
          }
          onBorrar={(imagen) =>
            accionDeImagen(
              imagen.tipo,
              () => borrarImagenDeProducto(id, imagen.id),
              'Imagen borrada'
            )
          }
        />
      )}

      {tab === 'categorias' && (
        <PestanaCategorias
          asignadas={producto.categorias}
          disponibles={categoriasDisponibles}
          onAsignar={(categoria) =>
            accionInmediata(
              () => asignarCategoriaAProducto(id, categoria.id),
              `Agregado a “${categoria.nombre}”`
            )
          }
          onQuitar={(categoria) =>
            accionInmediata(
              () => quitarCategoriaDeProducto(id, categoria.id),
              `Quitado de “${categoria.nombre}”`
            )
          }
        />
      )}
      </fieldset>


      {/* Datos muestra su error adentro del formulario e Imágenes arriba
          del grupo que falló; este del pie es solo para las otras dos. */}
      {error && (tab === 'materiales' || tab === 'categorias') && (
        <p role="alert" style={{ marginTop: 16, color: '#C0442F', fontSize: 14 }}>
          {error}
        </p>
      )}


      {modalMaterial && (
        <ModalAgregarMaterial
          materiales={materialesDisponibles}
          onCerrar={() => setModalMaterial(false)}
          onElegir={(material) => {
            setModalMaterial(false)
            accionInmediata(
              () => asignarMaterialAProducto(id, material.id),
              `“${material.nombre}” agregado`
            )
          }}
        />
      )}

      {modalBaja && (
        <ModalBajaProducto
          producto={producto}
          onCerrar={() => setModalBaja(false)}
          // Al darlo de baja se vuelve al listado, como en el prototipo: el
          // producto queda de solo lectura y no tiene sentido quedarse acá.
          onConfirmado={() => navegar(`${BASE_GESTION}/productos`)}
        />
      )}

      {toast && <Toast texto={toast} />}
    </div>
  )
}
