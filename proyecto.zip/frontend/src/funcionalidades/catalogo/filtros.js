// El filtro por categoría del catálogo público (CU64). Los filtros
// elegidos no se guardan en estado: viven en la dirección, como
// /?categoria=3&categoria=7, un parámetro por cada categoría elegida. Así
// una dirección con filtros se puede copiar, abrir en otra pestaña y
// sobrevive a recargar la página.
//
// Acá están las funciones que leen y escriben esa dirección y las que
// filtran. Ninguna pide nada al servidor: todas trabajan sobre las listas
// que el layout ya cargó.


// El orden en que se muestran los dos grupos: primero por tipo de
// accesorio, después por temática, como el diseño. El backend los manda al
// revés, porque ordena por el código y TEMATICA va antes que TIPO.
const ORDEN_DE_GRUPOS = ['TIPO', 'TEMATICA']


// Arma los grupos del árbol y de los filtros. Cada categoría sale con su
// cantidad de productos, contada sobre la lista completa; las que no
// tienen ninguno no salen, y un grupo que queda vacío tampoco.
//
// El título de cada grupo es el tipo_display que manda el backend ("Tipo
// de accesorio", "Temática"): acá no se traduce ningún código.
export function agruparCategorias(categorias, productos) {
  const conCantidad = categorias
    .map((categoria) => ({
      ...categoria,
      cantidad: productos.filter((producto) =>
        producto.categorias.some((c) => c.id === categoria.id)
      ).length,
    }))
    .filter((categoria) => categoria.cantidad > 0)

  return ORDEN_DE_GRUPOS
    .map((tipo) => conCantidad.filter((categoria) => categoria.tipo === tipo))
    .filter((delGrupo) => delGrupo.length > 0)
    .map((delGrupo) => ({
      tipo: delGrupo[0].tipo,
      titulo: delGrupo[0].tipo_display,
      categorias: delGrupo,
    }))
}


// Las categorías de un producto en el mismo orden que los grupos: primero
// las de tipo de accesorio y después las de temática.
export function ordenarCategorias(categorias) {
  return ORDEN_DE_GRUPOS.flatMap((tipo) =>
    categorias.filter((categoria) => categoria.tipo === tipo)
  )
}


// LEE los filtros de la dirección: los ids de las categorías elegidas.
// Solo devuelve los que existen entre las categorías que se muestran, así
// un id viejo o mal escrito en la dirección no filtra ni se cuenta.
export function leerFiltros(parametros, grupos) {
  const enLaUrl = parametros.getAll('categoria').map(Number)

  return grupos
    .flatMap((grupo) => grupo.categorias)
    .map((categoria) => categoria.id)
    .filter((id) => enLaUrl.includes(id))
}


// ESCRIBE los filtros: arma lo que recibe setSearchParams. Una lista en un
// valor se convierte en el parámetro repetido, y una lista vacía en
// ninguno.
export function escribirFiltros(ids) {
  return { categoria: ids.map(String) }
}


// Saca la categoría si estaba elegida y la agrega si no.
export function alternarFiltro(idsElegidos, id) {
  return idsElegidos.includes(id)
    ? idsElegidos.filter((elegido) => elegido !== id)
    : [...idsElegidos, id]
}


// O dentro de un grupo, Y entre grupos: con Aros, Dijes y Harry Potter
// elegidos quedan los aros y los dijes que sean de Harry Potter.
export function filtrarProductos(productos, grupos, idsElegidos) {
  return productos.filter((producto) => {
    const idsDelProducto = producto.categorias.map((c) => c.id)

    return grupos.every((grupo) => {
      const elegidasDelGrupo = grupo.categorias.filter((c) => idsElegidos.includes(c.id))

      // Un grupo sin nada elegido no filtra.
      if (elegidasDelGrupo.length === 0) return true

      return elegidasDelGrupo.some((c) => idsDelProducto.includes(c.id))
    })
  })
}


// El orden de los productos del listado (CU63). Como los filtros, vive en
// la dirección: ?orden=precio-desc. Si falta o trae otra cosa, vale el de
// por defecto, que no se escribe para que la dirección quede limpia.
//
// El orden se aplica SIEMPRE acá, también el de por defecto, aunque el
// backend ya mande los productos por nombre: PostgreSQL ordena con la
// intercalación de la base y localeCompare con la del español, y pueden
// diferir en tildes o mayúsculas. Con una sola autoridad, A–Z y Z–A son
// espejo exacto.
export const ORDENES = [
  { valor: 'nombre-asc', label: 'Nombre A–Z' },
  { valor: 'nombre-desc', label: 'Nombre Z–A' },
  { valor: 'precio-asc', label: 'Menor precio' },
  { valor: 'precio-desc', label: 'Mayor precio' },
]

export const ORDEN_POR_DEFECTO = 'nombre-asc'


// LEE el orden de la dirección. Solo acepta uno de ORDENES.
export function leerOrden(parametros) {
  const enLaUrl = parametros.get('orden')
  return ORDENES.some((orden) => orden.valor === enLaUrl) ? enLaUrl : ORDEN_POR_DEFECTO
}


// ESCRIBE el orden: el de por defecto no va a la dirección.
export function escribirOrden(orden) {
  return orden === ORDEN_POR_DEFECTO ? {} : { orden }
}


// Devuelve una copia ordenada: sort() ordena en el lugar y la lista que
// llega no es nuestra. El precio viaja como texto ("1500.00"), por eso
// Number(): como texto, "900.00" iría después de "1500.00". Dos productos
// con el mismo precio quedan como venían, que es por nombre.
export function ordenarProductos(productos, orden) {
  const [campo, direccion] = orden.split('-')
  const signo = direccion === 'asc' ? 1 : -1

  return productos.slice().sort((x, y) => {
    if (campo === 'precio') return (Number(x.precio_actual) - Number(y.precio_actual)) * signo
    return x.nombre.localeCompare(y.nombre, 'es') * signo
  })
}


// La búsqueda por texto del listado. Como los filtros y el orden, vive en
// la dirección: ?busqueda=aros. Es "contiene", sin distinguir mayúsculas
// ni acentos, en el nombre o la descripción.
//
// "jose" encuentra "José": NFD separa cada letra acentuada en la letra y
// su acento, y el rango ̀-ͯ son justamente los acentos, que se
// quitan antes de comparar en minúscula. Es sinAcentos de
// componentes/SelectorBuscable.jsx, que no la exporta.
function normalizar(texto) {
  return texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
}


// LEE la búsqueda de la dirección: el texto tal cual, o vacío.
export function leerBusqueda(parametros) {
  return parametros.get('busqueda') ?? ''
}


// ESCRIBE la búsqueda: un texto en blanco no va a la dirección.
export function escribirBusqueda(busqueda) {
  return busqueda.trim() === '' ? {} : { busqueda }
}


// Los productos cuyo nombre o descripción contienen el texto. Sin texto,
// todos.
export function buscarProductos(productos, busqueda) {
  const texto = normalizar(busqueda.trim())
  if (texto === '') return productos

  return productos.filter(
    (producto) =>
      normalizar(producto.nombre).includes(texto) ||
      normalizar(producto.descripcion ?? '').includes(texto)
  )
}
