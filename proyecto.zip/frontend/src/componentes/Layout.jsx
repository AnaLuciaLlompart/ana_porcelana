import { useState, useEffect } from 'react'
import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../contexto/AuthContext'
import { BASE_GESTION } from '../constantes'
import { FAVICON_GESTION, cambiarFavicon } from '../favicon'

// Iconos del menú, tomados del diseño (estilo Heroicons outline)
const NAV = [
  { id: 'inicio', label: 'Inicio', ruta: BASE_GESTION, icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
  { id: 'materiales', label: 'Materiales', ruta: `${BASE_GESTION}/materiales`, icon: 'M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z' },
  { id: 'categorias', label: 'Categorías', ruta: `${BASE_GESTION}/categorias`, icon: 'M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A2 2 0 013 12V7a4 4 0 014-4z' },
  { id: 'productos', label: 'Productos', ruta: `${BASE_GESTION}/productos`, icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
  { id: 'clientes', label: 'Clientes', ruta: `${BASE_GESTION}/clientes`, icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z' },
  { id: 'pedidos', label: 'Pedidos', ruta: `${BASE_GESTION}/pedidos`, icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
  { id: 'gastos', label: 'Gastos', ruta: `${BASE_GESTION}/gastos`, icon: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z' },
  { id: 'finanzas', label: 'Finanzas', ruta: `${BASE_GESTION}/finanzas`, icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
]

const ICONO_SALIR = 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1'
const ICONO_CUENTA = 'M5.121 17.804A13 13 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z'
const ICONO_MENU = 'M4 6h16M4 12h16M4 18h16'

// Tiene que ser el mismo 768 que la media query de index.css: React decide
// qué dibujar según este valor y CSS cómo se ve, y los dos tienen que
// cambiar en el mismo ancho.
const PANTALLA_CHICA = '(max-width: 768px)'

function Item({ icon, label, activo, expandida, onClick, title }) {
  const color = activo ? 'white' : 'rgba(255,255,255,.75)'

  return (
    <button
      onClick={onClick}
      title={title}
      className="nav-item"
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        height: 42,
        padding: '0 10px',
        borderRadius: 6,
        border: 0,
        cursor: 'pointer',
        width: '100%',
        background: activo ? 'rgba(255,255,255,.2)' : 'transparent',
        justifyContent: expandida ? 'flex-start' : 'center',
      }}
    >
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke={color} strokeWidth="1.8" style={{ flexShrink: 0 }}>
        <path strokeLinecap="round" strokeLinejoin="round" d={icon} />
      </svg>
      {expandida && (
        <span style={{
          fontFamily: "'Quicksand', sans-serif",
          fontWeight: 600,
          fontSize: 15,
          whiteSpace: 'nowrap',
          color,
        }}>
          {label}
        </span>
      )}
    </button>
  )
}

// Dice si la pantalla es chica (768px o menos) y se actualiza sola cuando
// la ventana cruza ese ancho. Empieza con use porque React y su linter
// reconocen los hooks por ese prefijo, igual que useAuth.
function usePantallaChica() {
  const [chica, setChica] = useState(() => window.matchMedia(PANTALLA_CHICA).matches)

  useEffect(() => {
    const consulta = window.matchMedia(PANTALLA_CHICA)
    const actualizar = (evento) => setChica(evento.matches)
    consulta.addEventListener('change', actualizar)
    return () => consulta.removeEventListener('change', actualizar)
  }, [])

  return chica
}

export default function Layout() {
  const pantallaChica = usePantallaChica()
  const [expandida, setExpandida] = useState(true)
  const [menuAbierto, setMenuAbierto] = useState(false)
  const navegar = useNavigate()
  const ubicacion = useLocation()
  const { salir } = useAuth()

  // La ruta actual sin la barra final, si la trae. React Router muestra la
  // misma pantalla con o sin ella, pero no corrige la dirección: si alguien
  // escribe a mano la de Inicio con una barra al final, pathname llega así
  // y no sería igual a BASE_GESTION.
  const rutaActual = ubicacion.pathname.endsWith('/')
    ? ubicacion.pathname.slice(0, -1)
    : ubicacion.pathname

  // En pantalla chica la barra se dibuja siempre expandida: lo que la muestra
  // u oculta es el deslizamiento, no el ancho. En escritorio manda el botón
  // Menú, como siempre.
  const conNombres = pantallaChica || expandida

  // El panel solo existe en pantalla chica. Si la ventana pasa a escritorio
  // con el menú abierto, menuAbierto queda en true pero no se ve nada, y al
  // volver a pantalla chica el panel reaparece como se lo dejó.
  const panelAbierto = pantallaChica && menuAbierto

  // El ícono de la pestaña de la gestión. Se pone al montar y nunca más:
  // si la usuaria vuelve al catálogo, LayoutPublico pone el suyo.
  useEffect(() => {
    cambiarFavicon(FAVICON_GESTION)
  }, [])

  // Escape cierra el panel. Se escucha solo mientras está abierto.
  useEffect(() => {
    if (!panelAbierto) return
    function alTeclear(evento) {
      if (evento.key === 'Escape') setMenuAbierto(false)
    }
    document.addEventListener('keydown', alTeclear)
    return () => document.removeEventListener('keydown', alTeclear)
  }, [panelAbierto])

  function irA(ruta) {
    navegar(ruta)
    setMenuAbierto(false)
  }

  async function manejarSalir() {
    await salir()
    navegar(`${BASE_GESTION}/login`)
  }

  return (
    <div style={{ display: 'flex', height: '100dvh', overflow: 'hidden', background: '#FAF7F7' }}>

      <aside className={panelAbierto ? 'barra-lateral abierta' : 'barra-lateral'} style={{
        display: 'flex',
        flexDirection: 'column',
        flexShrink: 0,
        overflow: 'hidden',
        background: '#8C5A66',
        transition: 'width .2s',
        width: conNombres ? 210 : 58,
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: '12px 6px 0', flex: 1 }}>

          <Item
            icon={ICONO_MENU}
            label="Menú"
            activo={false}
            expandida={conNombres}
            onClick={() => (pantallaChica ? setMenuAbierto(false) : setExpandida((v) => !v))}
            title="Menú"
          />

          <div style={{ height: 1, background: 'rgba(255,255,255,.15)', margin: '6px 0' }} />

          {NAV.map((item) => (
            <Item
              key={item.id}
              icon={item.icon}
              label={item.label}
              title={item.label}
              expandida={conNombres}
              activo={rutaActual === item.ruta}
              onClick={() => irA(item.ruta)}
            />
          ))}
        </div>

        <div style={{ padding: '0 6px 16px' }}>
          <div style={{ height: 1, background: 'rgba(255,255,255,.15)', marginBottom: 6 }} />
          {/* Mi cuenta no va en NAV: esa lista es la de los módulos de
              gestión, y esto es la cuenta de quien está usando el sistema. */}
          <Item
            icon={ICONO_CUENTA}
            label="Mi cuenta"
            title="Mi cuenta"
            expandida={conNombres}
            activo={rutaActual === `${BASE_GESTION}/mi-cuenta`}
            onClick={() => irA(`${BASE_GESTION}/mi-cuenta`)}
          />
          <Item
            icon={ICONO_SALIR}
            label="Cerrar sesión"
            title="Cerrar sesión"
            activo={false}
            expandida={conNombres}
            onClick={manejarSalir}
          />
        </div>
      </aside>

      {/* Fondo oscuro detrás del panel en pantalla chica, con los mismos
          valores que el de los modales. Tocarlo cierra el menú. */}
      {panelAbierto && (
        <div
          onClick={() => setMenuAbierto(false)}
          style={{ position: 'fixed', inset: 0, background: 'rgba(61,50,56,.5)', zIndex: 90 }}
        />
      )}

      <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
        {/* Franja superior de pantalla chica: solo existe cuando la barra
            lateral no se ve. El ☰ abre el panel. */}
        {pantallaChica && (
          <header style={{
            display: 'flex', alignItems: 'center', gap: 10,
            height: 48, flexShrink: 0, padding: '0 8px', background: '#8C5A66',
          }}>
            <button
              onClick={() => setMenuAbierto(true)}
              title="Menú"
              className="nav-item"
              style={{
                width: 36, height: 36, padding: 0, border: 0, borderRadius: 6,
                background: 'transparent', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.8">
                <path strokeLinecap="round" strokeLinejoin="round" d={ICONO_MENU} />
              </svg>
            </button>
            {/* En Inicio no se repite el nombre: el título de esa pantalla ya
                dice Ana Porcelana. */}
            {rutaActual !== BASE_GESTION && (
              <span style={{ fontFamily: "'Quicksand', sans-serif", fontWeight: 600, fontSize: 17, color: 'white' }}>
                Ana Porcelana
              </span>
            )}
          </header>
        )}

        {/* scrollbarGutter reserva el espacio de la barra de scroll aunque
            no haga falta, así el ancho del contenido no cambia cuando una
            pantalla crece y la barra aparece. */}
        <main className="contenido" style={{ flex: 1, overflowY: 'auto', scrollbarGutter: 'stable', padding: 32 }}>
          <Outlet />
        </main>
      </div>
    </div>
  )
}