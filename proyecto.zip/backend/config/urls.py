from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/', include('usuarios.urls')),
    path('api/materiales/', include('materiales.urls')),
    path('api/categorias/', include('categorias.urls')),
    path('api/productos/', include('productos.urls')),
    path('api/clientes/', include('clientes.urls')),
    path('api/pedidos/', include('pedidos.urls')),
    path('api/gastos/', include('gastos.urls')),
    path('api/finanzas/', include('finanzas.urls')),
    path('api/inicio/', include('inicio.urls')),
    path('api/catalogo/', include('catalogo.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)