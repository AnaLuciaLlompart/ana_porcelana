from django.contrib import admin

from .models import Cobro, Pedido, ProductoDelPedido


# El inline es un formulario de un modelo hijo incrustado dentro del
# formulario del padre. Sirve para cargar un pedido con sus productos de
# una sola vez: sin él habría que guardar el pedido primero y recién
# después ir a agregarle los productos uno por uno.

class ProductoDelPedidoInline(admin.TabularInline):
    model = ProductoDelPedido


class CobroInline(admin.TabularInline):
    model = Cobro


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    list_display = ('id', 'cliente', 'estado', 'fecha_pedido', 'fecha_entrega_estimada')
    list_filter = ('estado', 'envio_a_cargo')

    # El doble guion bajo salta a la tabla de al lado: el pedido no
    # tiene instagram ni nombre, los tiene el cliente al que apunta la
    # clave foránea.
    search_fields = ('cliente__instagram', 'cliente__nombre')

    inlines = [ProductoDelPedidoInline, CobroInline]
