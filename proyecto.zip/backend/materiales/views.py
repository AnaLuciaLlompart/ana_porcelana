from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Material
from .serializers import MaterialSerializer

# Views: aplica las reglas de negocio, verifica permisos, orquesta el serializer y model, verifica permisos

class MaterialViewSet(viewsets.ModelViewSet): # ModelViewSet es la clase que ya cuenta con las operaciones del CRUD: listar, ver uno, crear, modificar y eliminar
    """CRUD de materiales (CU04 a CU10).

    Hereda IsAuthenticated de la configuración global de DRF, por lo
    que todos los endpoints exigen sesión activa.

    Devuelve todos los materiales, activos y discontinuados. La
    separación visual entre ambos grupos se resuelve en el frontend,
    dado el volumen acotado de registros.
    """

    queryset = Material.objects.all()
    serializer_class = MaterialSerializer 

    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['nombre', 'descripcion']
    ordering_fields = ['nombre', 'disponibilidad', 'estado']


    # ----------------------------------------------------------------
    # Sobreescribo update, ya que no puedo modificar materiales discontinuados
    # -----------------------------------------------------------------

    def update(self, request, *args, **kwargs):
        """Impide modificar un material discontinuado.

        Un material discontinuado queda de solo lectura: sigue
        referenciado en productos y gastos anteriores, por lo que
        alterar su nombre o disponibilidad modificaría cómo se
        interpreta el historial. Para volver a editarlo hay que
        reactivarlo primero.

        Cubre PUT y PATCH: DRF resuelve el PATCH llamando a update. (PATCH es como PUT pero solo con las modificaciones)
        """
        material = self.get_object()

        if material.estado == Material.Estado.DISCONTINUADO:
            return Response(
                {'detail': 'El material está discontinuado. '
                           'Reactivalo para poder modificarlo.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().update(request, *args, **kwargs)


    # -----------------------------------------------------------------
    # Sobreescribo destroy, para explicar por qué no se puede eliminar
    # -----------------------------------------------------------------

    def destroy(self, request, *args, **kwargs):
        """Impide eliminar un material que algún producto usa o que figura en algún gasto.

        Las claves foráneas de MaterialProducto y de MaterialDelGasto son
        PROTECT, así que la base rechaza el borrado igual. Pero sin este
        chequeo la excepción sale como un 500 con el traceback, y quien
        está del otro lado no se entera de por qué falló ni en cuántos
        productos y gastos está el material.
        """
        material = self.get_object()

        # Acá sí corresponde .count(): es un solo material y no hay ningún
        # prefetch que respetar, así que conviene una consulta que devuelve
        # un número antes que traerse las filas para contarlas en Python.
        #
        # Se cuentan las dos claves foráneas con PROTECT que apuntan a
        # Material: los productos que lo llevan (MaterialProducto) y los
        # gastos en los que se compró (MaterialDelGasto). Cualquiera de las
        # dos hace que la base rechace el borrado.
        en_productos = material.usos.count()
        en_gastos = material.en_gastos.count()

        if en_productos > 0 or en_gastos > 0:
            # El mensaje nombra solo lo que corresponde: "está usado en 2
            # productos", "figura en 1 gasto", o las dos cosas unidas con
            # una "y".
            motivos = []

            if en_productos > 0:
                motivos.append(
                    'está usado en '
                    + ('1 producto' if en_productos == 1 else f'{en_productos} productos')
                )

            if en_gastos > 0:
                motivos.append(
                    'figura en '
                    + ('1 gasto' if en_gastos == 1 else f'{en_gastos} gastos')
                )

            return Response(
                {'detail': f'No se puede eliminar «{material.nombre}» porque '
                           f'{" y ".join(motivos)}. Si ya no lo conseguís o no '
                           f'lo querés usar más, discontinualo.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().destroy(request, *args, **kwargs)


    # -----------------------------------------------------------------
    # Acciones propias, además del CRUD (activar y desactivar)
    # -----------------------------------------------------------------

    @action(detail=True, methods=['post'])
    def discontinuar(self, request, pk=None):
        """CU09 - Dar de baja un material.

        Baja lógica: el registro se conserva y solo cambia su estado.
        Los materiales discontinuados siguen referenciados en productos
        y gastos anteriores, por lo que eliminarlos rompería el
        historial.
        """
        material = self.get_object()

        if material.estado == Material.Estado.DISCONTINUADO:
            return Response(
                {'detail': 'El material ya está discontinuado.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        material.estado = Material.Estado.DISCONTINUADO
        material.save(update_fields=['estado'])

        return Response(self.get_serializer(material).data)

    @action(detail=True, methods=['post'])
    def reactivar(self, request, pk=None):
        """Vuelve a poner en uso un material discontinuado.

        Se permite aunque el material esté discontinuado: es la única
        vía para devolverlo a estado editable.
        """
        material = self.get_object()

        if material.estado == Material.Estado.ACTIVO:
            return Response(
                {'detail': 'El material ya está activo.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        material.estado = Material.Estado.ACTIVO
        material.save(update_fields=['estado'])

        return Response(self.get_serializer(material).data)

